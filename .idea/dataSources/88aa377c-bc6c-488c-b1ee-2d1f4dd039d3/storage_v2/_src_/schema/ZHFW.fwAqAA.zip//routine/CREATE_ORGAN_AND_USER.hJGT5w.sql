CREATE PROCEDURE "CREATE_ORGAN_AND_USER"(
p_CORPORATION_ID in varchar2,
p_DEPARTMENT_ID in varchar2,
p_organ_id in varchar2,
p_organ_code in varchar2,
p_organ_name in varchar2,
p_parent_id  in varchar2,
p_stru_level  in number,
p_stru_path in varchar2,
p_stru_id in varchar2,
p_stru_ext_id1 in varchar2,
p_stru_ext_id2 in varchar2,
p_create_time in char,
p_user_id in varchar2,
p_password in varchar2,
p_is_sys in char,
p_pwd_time in char,
p_USERMAILADDRESS in varchar2,
p_ID_TYPE in char,
p_USERALIAS in varchar2,
p_CONTACT in varchar2,
p_USER_TYPE in char,
p_CITY in varchar2,
p_user_PARENT_ID in varchar2,
p_CORPNAME in varchar2,
p_PROVINCE in varchar2,
p_USERHOMEADDRESS in varchar2,
p_USERPHONE in varchar2,
p_ISCA in char,
p_USERRANK in varchar2,
p_CORPID in varchar2,
p_FAX in varchar2,
p_USERNT in varchar2,
p_USERPOSTCODE in varchar2,
p_USERMOBILEPHONE in varchar2,
p_COUNTY in varchar2,
p_ID_CODE in varchar2,
p_USERSEX in char,
p_USERPOST in varchar2,
p_USERMSN in varchar2,
p_USERDUTY in varchar2,
p_sqgw in varchar2,
p_isRealName in varchar2
)
as
begin
insert into PUB_ORGAN(ORGAN_ID,ORGAN_TYPE,ORGAN_CODE,IN_USE,SHORT_NAME,ORGAN_NAME)
values (p_organ_id,'8',p_organ_code,'1','',p_organ_name);
insert into PUB_STRU(ORGAN_ID,POSITION_CODE,PARENT_ID,STRU_TYPE,STRU_NAME,IN_USE,STRU_LEVEL,IS_LEAF,STRU_ORDER,STRU_PATH,STRU_CODE,STRU_ID)
values (p_organ_id,'',p_parent_id,'00','','1',p_stru_level,'1',600,p_stru_path,'',p_stru_id);
insert into PUB_STRU_EXT(ID,STRU_TYPE,SRC_ID,TARGET_ID,TYPE,STRU_ID)
values (p_stru_ext_id1,'00',p_organ_id,p_CORPORATION_ID,'00',p_stru_id);
insert into PUB_STRU_EXT(ID,STRU_TYPE,SRC_ID,TARGET_ID,TYPE,STRU_ID)
values (p_stru_ext_id2,'00',p_organ_id,p_CORPORATION_ID,'01',p_stru_id);
insert into PUB_USERS(CREATE_TIME,LOCK_TIME,ACCOUNT_STATUS,USER_ID,EXPIRED_TIME,USER_NAME,USER_TYPE_CODE,PASSWORD,PWD_UPT_TIME,IS_SYS,PWD_TIME)
values (p_create_time,'','11',p_user_id,'99991231 23:59:59',p_organ_name,'00',p_password,p_create_time,p_is_sys,p_pwd_time);
insert into PUB_USER_EMPLOYEE(EMPLOYEE_ID,CORPORATION_ID,USER_ID,DEPARTMENT_ID)
values (p_stru_id,p_CORPORATION_ID,p_user_id,p_DEPARTMENT_ID) ;
insert into PUB_USER_POLICY(MAX_SESSION_NUMBER,IS_USE_IP,USER_ID,IP_POLICY_VALUE)
values (1,'0',p_user_id,'');
insert into EXT_USERINFO(USERMAILADDRESS,ID_TYPE,USEROICQNO,USERALIAS,PASSWORD,CONTACT,USERBIRTHDAY,USER_TYPE,
CITY,PARENT_ID,CORPNAME,USER_ID,PROVINCE,USERHOMEADDRESS,USERPHONE,ISCA,USERRANK,CORPID,USERCA,FAX,USERNT,
USERPOSTCODE,USERMOBILEPHONE,COUNTY,ID_CODE,USERSEX,USERPOST,USERMSN,ALARM_URL,USERDUTY,ISSHOW,USERFLAG,UCUID,UC_USER_TYPE,SQGW)
values (p_USERMAILADDRESS,'1','',p_USERALIAS,'',p_CONTACT,'',p_USER_TYPE,
p_CITY,p_user_PARENT_ID,p_CORPNAME,p_user_id,p_PROVINCE,p_USERHOMEADDRESS,p_USERPHONE,p_ISCA,p_USERRANK,p_CORPID,'',p_FAX,p_USERNT,
p_USERPOSTCODE,p_USERMOBILEPHONE,p_COUNTY,p_ID_CODE,p_USERSEX,p_USERPOST,p_USERMSN,'',p_USERDUTY,'','1',p_user_id,'11',p_sqgw) ;
if p_isRealName = '1' then
  insert into realname_verification (USER_ID, USER_NAME, ID_CODE, CREATE_TIME, CHECK_TIME, REAL_NAME_CHECK_TYPE)
values (p_user_id, p_organ_name, p_ID_CODE, p_create_time, '', '0');
  end if;
commit;
end;
/

