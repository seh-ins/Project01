CREATE function fn_getxn(dt in varchar) return varchar2 is
  Result varchar2(4);
  ----------------------------------------------------------------------
  --?????????????????null???sysdate???
  --??????
  --?????2015?9?22?14:20:20
  --?????
  --?????
  ----------------------------------------------------------------------
  calcdt date; --???????
  v_cmd  varchar2(4); --??
  v_csmd varchar2(4); --??????
begin
  v_csmd := '0901';
  if dt is null then
    calcdt := sysdate;
  else
      calcdt := to_date(dt,'yyyy-mm-dd');
  end if;

  v_cmd := to_char(calcdt, 'mmdd');
  if v_cmd >= v_csmd then

    Result := to_char(calcdt, 'yyyy');
  else
    Result := to_char(add_months(calcdt, -12), 'yyyy');
  end if;
  return(Result);
end;
/

