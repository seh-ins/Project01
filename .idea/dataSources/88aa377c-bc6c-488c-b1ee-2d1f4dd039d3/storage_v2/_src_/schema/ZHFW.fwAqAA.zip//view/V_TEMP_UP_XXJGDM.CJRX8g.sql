CREATE VIEW V_TEMP_UP_XXJGDM AS
  select j."NF",j."BBMC",j."XXJGMC",j."XXJGBSM",j."XXJGDZDM",j."XXJGSDGLJYXZBMDM",j."XXJGJBZM",j."XXJGBXLXM",j."XXJGXZLBM",j."XXJGSZDCXFLM",j."DLSZSSMZXXJG",j."SFXSLXX",j."SFCX",j."CBDXXJGBSM",j."XTGXRQ",j."XXJGID",j."XXJGCJBMDM" from jg_xxjgdm j where j.sfcx = '??' and  j.xxjgbsm  in ( select t.xxjgbsm from moe_norm_xxjgdm t )
/

